import React from 'react'
import "./MinLoader.css"

function MinLoader() {
  return (
    <span className='loader'></span>
  )
}

export default MinLoader